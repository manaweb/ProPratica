<?
	header('Location: ./sys/index.php');
?>