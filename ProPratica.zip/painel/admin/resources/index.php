<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<title>Erro</title>
<style type="text/css">
<!--
body {
	background-color: #fff;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	font-size:30px;
	font-family:arial;
	font-weight:bold;
	letter-spacing:-2px;
	color:#222;
}
span {color:red;}
a {color:#222; font-size:16px;text-decoration:none;letter-spacing:-1px;font-weight:normal;}
a:hover{text-decoration:underline;}
-->
</style></head>

<body>
<div align="center">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p><span>ERRO: </span>P�gina n�o encontrada<br><br><a href="../">Clique aqui para voltar</a>      </p>
</div>
</body>
</html>