<? 
	include('../includes/Config.php');

	define('ID_MODULO',0,true);
	include('../includes/Topo.php');
	
?>
<?
include('../includes/Mensagem.php');
?>
                	<div class="conthead">
                        <h2>Erro</h2>
                    </div>
<div id="conteudo">
 
Recebemos o LOG (erro: 1E6WS11EAEAE61849189496A) deste erro, estamos trabalhando para resolver o mais breve possível.
<br />
<br />

</div>
<?
	include('../includes/Rodape.php');
?>