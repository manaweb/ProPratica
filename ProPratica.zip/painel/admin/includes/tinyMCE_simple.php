<script language="javascript" type="text/javascript" src="../../js/tiny_mce/tiny_mce.js"></script>
<script language="javascript" type="text/javascript">
tinyMCE.init({
	mode : "textareas",
	theme: "simple"
});
</script>