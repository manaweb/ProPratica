<html>
<head>
	<title>Calendario</title>
	<link rel="StyleSheet" type="text/css" href="../css/calendario.css" />
	<script type="text/javascript" language="javascript" src="../js/calendario.js"></script>
	<script type="text/javascript" language="javascript">
	//<![CDATA[
		var month_names = new Array("Janeiro","Fevereiro","Marco","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro");
		var day_names = new Array("Dom","Seg","Ter","Qua","Qui","Sex","Sab");
		var submit_text = "Ok";
	//]]>
	</script>
</head>
<body onLoad="initCalendar();">
<div id="calendar_data"></div>
<div id="clock_data"></div>
</body>
</html>